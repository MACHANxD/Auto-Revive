-- esx_autorevive/client.lua

local ESX = nil

-- TriggerEvent to get ESX object
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- Function to revive the player
local function revivePlayer()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    
    -- Ensure the player is dead
    if IsEntityDead(playerPed) then
        -- Play a revive animation (optional)
        RequestAnimDict('mini@cpr@char_a@cpr_str')
        while not HasAnimDictLoaded('mini@cpr@char_a@cpr_str') do
            Wait(100)
        end
        TaskPlayAnim(playerPed, 'mini@cpr@char_a@cpr_str', 'cpr_pumpchest', 8.0, -8.0, -1, 1, 0, false, false, false)

        -- Wait for 5 seconds
        Citizen.Wait(5000)

        -- Revive the player
        TriggerEvent('esx_ambulancejob:revive')
        
        -- Teleport the player to their current position (optional)
        SetEntityCoords(playerPed, coords.x, coords.y, coords.z, false, false, false, true)
        
        -- Clear the animation
        ClearPedTasks(playerPed)
    end
end

-- Key press event
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        
        -- Check if the player is dead and pressed the "E" key
        if IsEntityDead(playerPed) and IsControlJustReleased(0, 38) then -- 38 is the control ID for "E"
            revivePlayer()
        end
    end
end)